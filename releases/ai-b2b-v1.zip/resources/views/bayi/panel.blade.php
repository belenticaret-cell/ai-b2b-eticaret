@extends('layouts.app')

@section('content')
<div class="container py-5">
    <h1>Bayi Paneli</h1>
    <p>Hoş geldiniz, bayi olarak ürünlerinizi ve siparişlerinizi buradan yönetebilirsiniz.</p>
</div>
@endsection
