# Özellikler & Kullanım Videoları Playlist

Durum: Script (S), Kayıt (K), Kurgu (G), Yayın (Y)

1. Admin Panel Hızlı Tur — 3:00 — [S]
2. Ürün İçe Aktarma (XML) — 5:00 — [S]
3. Kategori & Marka Yönetimi — 4:00 — [S]
4. Özellik Yönetimi ve Ürün Özellikleri — 4:00 — [S]
5. Bayi Yönetimi ve Bayi Fiyat — 5:00 — [S]
6. Modül Yönetimi ve Entegrasyon — 4:00 — [S]
7. Vitrin, Sepet ve Sipariş — 5:00 — [S]
8. Anasayfa Yönetimi (Header/Footer/Logo) — 3:00 — [S]

YouTube Başlık Şablonu: "AI B2B: {Konu} (Kısa Tur)"
Açıklama: Ana adımlar, ilgili dökümantasyon linkleri, zaman damgaları
Etiketler: aib2b, eticaret, b2b, laravel, {konu}
