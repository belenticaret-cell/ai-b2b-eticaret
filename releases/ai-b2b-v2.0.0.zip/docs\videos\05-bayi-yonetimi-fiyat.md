# 05 — Bayi Yönetimi ve Bayi Fiyat (5:00)

Amaç: Bayi CRUD, kullanıcı oluşturma, bayi özel fiyat

## Adımlar
1. Bayi ekle, opsiyonel kullanıcı oluşturma
2. Ürün düzenle > Bayi Fiyat sekmesi
3. Bayi panel ve fiyat görünümü

## Voiceover
- "Bayiler için özel fiyatları kolayca tanımlayabilirsiniz..."
