<?php

namespace App\Models;

class User extends Kullanici
{
    // Bu sınıf, Breeze/Jetstream gibi paketlerin ve mevcut testlerin App\Models\User beklentisini
    // karşılamak için Kullanici modeline alias görevi görür.
}
