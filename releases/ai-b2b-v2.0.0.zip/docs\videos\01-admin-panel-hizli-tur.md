# 01 — Admin Panel Hızlı Tur (3:00)

Amaç: Yönetim paneli ana menüler, hızlı gezinme, önemli kısayollar.
Önkoşullar: Demo veri, admin erişimi

## Adımlar
1. Giriş ve dashboard
2. Üst açılır menüler: Katalog, İçerik, Entegrasyon, B2B, Ayarlar
3. Sol menü ve Modüller (collapsible)
4. Hızlı linkler ve AI araçları

## Voiceover Metni (özet)
- "Bu videoda admin panelin hızlı bir turunu yapacağız..."

## Ekran Planı
- 0:05 Dashboard
- 0:40 Üst menüler hover
- 1:30 Sol menü modüller
- 2:20 AI araçları

## Yayın
- Başlık: AI B2B: Admin Panel Hızlı Tur
- Açıklama: Menü ve kısayol tanıtımı
- Etiketler: aib2b, admin, laravel
