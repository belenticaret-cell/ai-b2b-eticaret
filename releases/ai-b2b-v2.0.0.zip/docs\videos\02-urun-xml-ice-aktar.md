# 02 — Ürün İçe Aktarma (XML) (5:00)

Amaç: XML ile marka/kategori/özellik uyumlu import
Önkoşul: Örnek XML dosyası

## Adımlar
1. Entegrasyon menüsünden XML içe aktar formu
2. Marka ve kategori eşlemesi (otomatik oluşturma)
3. Ürün görsel ve özellik (UrunOzellik) oluşturma
4. Hatalı XML durumunda hata mesajı

## Voiceover
- "XML içe aktarma ile ürünleri hızlıca ekleyebilirsiniz..."

## Yayın
- Başlık: AI B2B: XML ile Ürün İçe Aktarma
- Etiketler: aib2b, xml, import
