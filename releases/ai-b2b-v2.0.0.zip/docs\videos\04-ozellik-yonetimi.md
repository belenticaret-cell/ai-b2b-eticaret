# 04 — Özellik Yönetimi ve Ürün Özellikleri (4:00)

Amaç: Özellik (UrunOzellik) liste/filtre/CRUD

## Adımlar
1. Özellik yönetimi ekranı
2. Ürün bazlı filtreleme
3. Özellik ekle/düzenle/sil

## Voiceover
- "Dinamik ürün özelliklerini merkezi ekrandan yönetebilirsiniz..."
