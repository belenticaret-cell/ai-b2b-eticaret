# 07 — Vitrin, Sepet ve Sipariş (5:00)

Amaç: Vitrin gezinme, arama, sepet işlemleri

## Adımlar
1. Ürün listesi ve detay
2. Sepete ekle/çıkar
3. Ödeme akışına giriş (mock)

## Voiceover
- "Vitrin üzerinden hızlıca ürün bulup sepetinize ekleyebilirsiniz..."
