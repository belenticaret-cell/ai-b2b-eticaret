# 03 — Kategori & Marka Yönetimi (4:00)

Amaç: Ağaç yapıda kategori CRUD, marka CRUD

## Adımlar
1. Kategori ağacı, yeni kategori ekle
2. Sıra ve ebeveyn ayarları
3. Marka listesi ve yeni marka

## Voiceover
- "Kategori ağacı üzerinden yapılandırmayı yapabilir, markaları yönetebilirsiniz..."
