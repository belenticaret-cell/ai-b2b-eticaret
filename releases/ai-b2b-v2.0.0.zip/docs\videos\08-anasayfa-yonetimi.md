# 08 — Anasayfa Yönetimi (Header/Footer/Logo) (3:00)

Amaç: Header/Footer aktif-pasif, logo yükleme ve konumlandırma

## Adımlar
1. Admin > Anasayfa Yönetimi
2. Header/Footer anahtarları
3. Logo yükleme (PNG/SVG) ve max-height

## Voiceover
- "Anasayfanın başlık ve altlık alanlarını yönetebilir, logonuzu yükleyebilirsiniz..."
