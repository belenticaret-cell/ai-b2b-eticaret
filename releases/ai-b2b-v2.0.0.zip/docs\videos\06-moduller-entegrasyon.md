# 06 — Modül Yönetimi ve Entegrasyon (4:00)

Amaç: Modül aktif/pasif ve entegrasyon sayfaları

## Adımlar
1. Modül yönetimi
2. Entegrasyon ayarları ve mağazalar

## Voiceover
- "Modüler yapı ile ihtiyacınız olmayan bölümleri gizleyebilirsiniz..."
